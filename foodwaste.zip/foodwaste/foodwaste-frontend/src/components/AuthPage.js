import React, { useState } from 'react';
import Login from './Login';
import Signup from './Signup';

function AuthPage() {
  const [tab, setTab] = useState('login');

  return (
    <div className="auth-container">
      <div className="tabs">
        <button onClick={() => setTab('login')} className={tab === 'login' ? 'active' : ''}>Login</button>
        <button onClick={() => setTab('signup')} className={tab === 'signup' ? 'active' : ''}>Sign Up</button>
      </div>
      <div className="form-content">
        {tab === 'login' ? <Login /> : <Signup />}
      </div>
    </div>
  );
}

export default AuthPage;