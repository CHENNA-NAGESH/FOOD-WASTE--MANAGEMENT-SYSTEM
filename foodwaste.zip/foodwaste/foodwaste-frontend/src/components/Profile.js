import React, { useEffect, useState } from 'react';
import './Profile.css';
import axios from 'axios';

const PROFILE_PLACEHOLDER = 'https://ui-avatars.com/api/?name=User&background=7c3aed&color=fff&size=128';

export default function Profile() {
  const user = JSON.parse(localStorage.getItem('user')) || {};
  const [donatedFoods, setDonatedFoods] = useState([]);

  useEffect(() => {
    if (user && user.id) {
      axios.get('http://localhost:8080/api/food', {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`
        }
      })
      .then(res => {
        // Filter only foods donated by this user
        setDonatedFoods(res.data.filter(item => item.donor && item.donor.id === user.id));
      })
      .catch(() => setDonatedFoods([]));
    }
  }, [user]);

  const availableFoods = donatedFoods.filter(item => item.status === 'AVAILABLE');
  const claimedFoods = donatedFoods.filter(item => item.status === 'CLAIMED');

  return (
    <div className="profile-topbar-root">
      <div className="profile-topbar">
        <div className="profile-avatar">
          <img src={PROFILE_PLACEHOLDER} alt="Profile" />
        </div>
        <div className="profile-topbar-info">
          <h2 className="profile-name">{user.name || user.email}</h2>
          <div className="profile-role">{user.role}</div>
          <div className="profile-email">{user.email}</div>
          <div className="profile-location">{user.location}</div>
        </div>
      </div>
      <main className="profile-content">
        <h3 style={{ color: '#7c3aed', marginBottom: '1.5rem' }}>My Donated Food Items</h3>
        
        <h4 style={{ color: '#27ae60', marginBottom: '1rem' }}>Available</h4>
        <div className="profile-donated-grid">
          {availableFoods.length === 0 && <div>No available food items.</div>}
          {availableFoods.map(item => (
            <div className="profile-donated-card" key={item.id}>
              <div className="profile-donated-header">
                <span className="profile-donated-title">{item.type?.toUpperCase() || 'FOOD'}</span>
                <span className="profile-donated-status available">Available</span>
              </div>
              <div className="profile-donated-desc">{item.name}</div>
              <div className="profile-donated-info">
                <span>Quantity: {item.quantity}kg</span>
                <span>Expires: {item.expirationDate?.substring(0, 10)}</span>
              </div>
            </div>
          ))}
        </div>

        <h4 style={{ color: '#e74c3c', margin: '2.5rem 0 1rem 0' }}>Claimed</h4>
        <div className="profile-donated-grid">
          {claimedFoods.length === 0 && <div>No claimed food items.</div>}
          {claimedFoods.map(item => (
            <div className="profile-donated-card" key={item.id}>
              <div className="profile-donated-header">
                <span className="profile-donated-title">{item.type?.toUpperCase() || 'FOOD'}</span>
                <span className="profile-donated-status claimed">Claimed</span>
              </div>
              <div className="profile-donated-desc">{item.name}</div>
              <div className="profile-donated-info">
                <span>Quantity: {item.quantity}kg</span>
                <span>Expires: {item.expirationDate?.substring(0, 10)}</span>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}