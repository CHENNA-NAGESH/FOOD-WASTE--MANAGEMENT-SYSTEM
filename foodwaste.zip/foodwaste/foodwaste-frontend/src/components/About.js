import React from "react";
import BCKVID from "../assets/backgroundVideo.mp4";
import OverBuying from "../assets/Problems.jpeg";
import Wastemoney from "../assets/wasted-money.jpg";
import Envimpact from "../assets/environment-impact.jpg";
import Hunger from "../assets/hunger.jpg";
import Resources from "../assets/resources.jpg";
import Community from "../assets/community.jpg";
import Sustainable from "../assets/sustainable.jpg";
import underline1 from "../assets/underline-heading.png";
import Arrow1 from "../assets/arrow1.png";
import Sun from "../assets/Highlight_05.png";

const AboutUs = () => {
  return (
    <div>
      {/* Video Background */}
      <div id="layer"></div>
      <div className="video-background">
        <video autoPlay loop muted>
          <source src={BCKVID} type="video/mp4" />
        </video>
      </div>
      {/* Main Content */}
      <div className="aboutus-content-wrapper">
        <div className="content aboutus-content">
          <h1>
            <div className="main-heading">
              <div className="head-sentence1">
                <span className="quote">" </span>
                <span className="reduce">Reduce</span>{" "}
                <span className="food-waste">Food Waste</span>
              </div>
              <div className="head-sentence2">
                One Meal at a Time<span className="quote"> ! "</span>
              </div>
            </div>
          </h1>
          <p className="paragraph">
            <span className="highlight">
              Feed Forward's technology allows businesses & people to revolutionize
              <br />
              food donation, empower communities, and foster sustainable solutions.
            </span>
          </p>
        </div>
      </div>

      {/* Problems Section */}
      <div id="problems">
        <div className="the-problems">
          <div className="problems-section1">
            <div className="heading-highlights">
              <img id="highlight-heading" src={Sun} alt="Sun" />
              <h1 id="heading-problems">
                Why Was FeedForward{" "}
                <span className="created">
                  Created? <img id="underline1" src={underline1} alt="underline" />
                </span>
              </h1>
              <img id="arrow1" src={Arrow1} alt="arrow" />
            </div>
            <div className="cards aboutus-cards">
              <div className="card1 aboutus-card">
                <img id="WasteMoney" src={Wastemoney} alt="Waste of Money" />
                <h1>Wasted Money</h1>
                <p>
                  Food waste results in significant financial losses. Around the world,
                  it is estimated that <span id="para-highlights">we collectively waste ₹92,000 crores per annum on discarded food.</span>
                  By reducing waste, we can save money and support businesses.
                </p>
              </div>
              <div className="card2 aboutus-card">
                <img id="Envtimpact" src={Envimpact} alt="Environment Impact" />
                <h1>Environmental Impact</h1>
                <p>
                  Food waste has a considerable environmental footprint. Each year, it is estimated that wasted food contributes
                  [insert estimated amount] of global CO2 emissions.
                  By minimizing waste, we can significantly reduce our carbon footprint and help protect our environment.
                </p>
              </div>
              <div className="card3 aboutus-card">
                <img id="hunger" src={Hunger} alt="Poor hungry children" />
                <h1>Fighting Hunger</h1>
                <p>
                  While we throw away food, many people in our neighborhood and beyond face hunger and food insecurity.
                  By reducing waste, we can help ensure that everyone has access to nourishing meals and contribute to a more food-secure community.
                </p>
              </div>
              <div className="card4 aboutus-card">
                <img id="resources" src={Resources} alt="Farming" />
                <h1>Efficient Resource Use</h1>
                <p>
                  Wasting food means wasting valuable resources like water, energy, and land. By being mindful of our consumption and minimizing waste,
                  we can make the most of these resources and create a sustainable neighborhood.
                </p>
              </div>
              <div className="card5 aboutus-card">
                <img id="community" src={Community} alt="Community" />
                <h1>Community Responsibility</h1>
                <p>
                  As a close-knit neighborhood, we have a responsibility to each other and the planet. By reducing food waste,
                  we show care for our community, demonstrate good stewardship of resources, and set a positive example for others.
                </p>
              </div>
              <div className="card6 aboutus-card">
                <img id="sustainable" src={Sustainable} alt="Climate Protesters" />
                <h1>Building a Sustainable Future</h1>
                <p>
                  Food waste highlights inefficiencies in our food system. By addressing this issue,
                  we can contribute to a more efficient and resilient food system that benefits everyone in our neighborhood.
                  Together, we can create a sustainable future.
                </p>
              </div>
            </div>
          </div>
          <div className="collage">
            <img id="background-image" src={OverBuying} alt="Background" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutUs;