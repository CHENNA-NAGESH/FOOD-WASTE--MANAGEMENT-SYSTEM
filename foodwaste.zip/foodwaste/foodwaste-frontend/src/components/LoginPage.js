import React, { useState } from 'react';
import { login, getCurrentUser, signup } from '../api';
import './LoginPage.css';

export default function LoginPage() {
  const [tab, setTab] = useState('login');
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [signupName, setSignupName] = useState('');
  const [signupEmail, setSignupEmail] = useState('');
  const [signupPassword, setSignupPassword] = useState('');
  const [signupLocation, setSignupLocation] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Login handler
  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    try {
      const { data } = await login(loginEmail, loginPassword);
      localStorage.setItem('token', data.token);
      localStorage.setItem('role', data.role);

      // Fetch user details and store in localStorage
      const userRes = await getCurrentUser();
      localStorage.setItem('user', JSON.stringify(userRes.data));

      if (data.role === 'ADMIN') {
        window.location.href = '/admin';
      } else {
        window.location.href = '/home';
      }
    } catch (err) {
      if (err.response && err.response.status === 401) {
        setError('Invalid credentials');
      } else {
        setError('Network Error');
      }
    }
  };

  // Signup handler
  const handleSignup = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    try {
      await signup({
        name: signupName,
        email: signupEmail,
        password: signupPassword,
        location: signupLocation,
      });
      setSuccess('Signup successful! Please login.');
      setTab('login');
      setSignupName('');
      setSignupEmail('');
      setSignupPassword('');
      setSignupLocation('');
    } catch (err) {
      if (err.response && err.response.status === 409) {
        setError('Email already in use.');
      } else {
        setError('Signup failed. Please try again.');
      }
    }
  };

  return (
    <div className="login-bg">
      <div className="login-form-container">
        <div className="tabs">
          <button
            className={tab === 'login' ? 'active' : ''}
            onClick={() => { setTab('login'); setError(''); setSuccess(''); }}
          >
            Login
          </button>
          <button
            className={tab === 'signup' ? 'active' : ''}
            onClick={() => { setTab('signup'); setError(''); setSuccess(''); }}
          >
            Sign Up
          </button>
        </div>
        {tab === 'login' ? (
          <form onSubmit={handleLogin}>
            <label>Email</label>
            <input
              type="email"
              value={loginEmail}
              onChange={e => setLoginEmail(e.target.value)}
              required
            />
            <label>Password</label>
            <input
              type="password"
              value={loginPassword}
              onChange={e => setLoginPassword(e.target.value)}
              required
            />
            <button type="submit">Login</button>
            {error && <div className="error">{error}</div>}
            {success && <div className="success">{success}</div>}
          </form>
        ) : (
          <form onSubmit={handleSignup}>
            <label>Name</label>
            <input
              type="text"
              value={signupName}
              onChange={e => setSignupName(e.target.value)}
              required
            />
            <label>Email</label>
            <input
              type="email"
              value={signupEmail}
              onChange={e => setSignupEmail(e.target.value)}
              required
            />
            <label>Password</label>
            <input
              type="password"
              value={signupPassword}
              onChange={e => setSignupPassword(e.target.value)}
              required
            />
            <label>Location</label>
            <input
              type="text"
              value={signupLocation}
              onChange={e => setSignupLocation(e.target.value)}
              required
            />
            <button type="submit">Sign Up</button>
            {error && <div className="error">{error}</div>}
            {success && <div className="success">{success}</div>}
          </form>
        )}
      </div>
    </div>
  );
}