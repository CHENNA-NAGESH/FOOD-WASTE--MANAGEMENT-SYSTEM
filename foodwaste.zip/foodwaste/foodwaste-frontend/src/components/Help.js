import React from 'react';

export default function Help() {
  return (
    <div>
      <h1>Help</h1>
      <p>This is the Help page. Add your content here.</p>
    </div>
  );
}