import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import './SideBar.css';

export default function SideBar() {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('user');
    localStorage.removeItem('token');
    navigate('/');
    window.location.reload();
  };

  return (
    <aside className="sidebar">
      <div className="sidebar-title">
        <span className="sidebar-title-main">Feed</span>
        <br />
        <span className="sidebar-title-main">Forward</span>
      </div>
      <div className="sidebar-divider"></div>
      <NavLink to="/home/donate" className="sidebar-link">
        <span className="sidebar-icon">
          {/* Donate Icon */}
          <svg width="20" height="20" fill="white" viewBox="0 0 24 24">
            <path d="M12 21c-4.97-4.97-8-7.99-8-11.5C4 5.42 6.42 3 9.5 3c1.74 0 3.41 0.81 4.5 2.09C15.09 3.81 16.76 3 18.5 3 21.58 3 24 5.42 24 8.5c0 3.51-3.03 6.53-8 11.5z"/>
          </svg>
        </span>
        Donate
      </NavLink>
      <NavLink to="/home/order-tracking" className="sidebar-link">
        <span className="sidebar-icon">
          {/* Order Tracking Icon */}
          <svg width="20" height="20" fill="white" viewBox="0 0 24 24">
            <rect x="4" y="4" width="16" height="16" rx="2"/>
            <path d="M9 2v4h6V2"/>
          </svg>
        </span>
        Order Tracking
      </NavLink>
      <NavLink to="/home/available-status" className="sidebar-link">
        <span className="sidebar-icon">
          {/* Available Status Icon */}
          <svg width="20" height="20" fill="white" viewBox="0 0 24 24">
            <circle cx="12" cy="12" r="10" stroke="white" strokeWidth="2" fill="none"/>
            <path d="M9 12l2 2l4-4" stroke="white" strokeWidth="2" fill="none"/>
          </svg>
        </span>
        Available Status
      </NavLink>
      <div className="sidebar-spacer"></div>
      <button className="sidebar-link sidebar-logout" onClick={handleLogout} type="button">
        <span className="sidebar-icon">
          {/* Logout Icon */}
          <svg width="22" height="22" fill="white" viewBox="0 0 24 24">
            <path d="M16 17v1a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h7a2 2 0 0 1 2 2v1" fill="none" stroke="white" strokeWidth="2"/>
            <polyline points="7 12 21 12" fill="none" stroke="white" strokeWidth="2"/>
            <polyline points="18 15 21 12 18 9" fill="none" stroke="white" strokeWidth="2"/>
          </svg>
        </span>
        Logout
      </button>
    </aside>
  );
}