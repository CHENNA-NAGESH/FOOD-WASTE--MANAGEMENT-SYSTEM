import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import './AdminSideBar.css';

export default function AdminSideBar() {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('user');
    localStorage.removeItem('token');
    navigate('/');
    window.location.reload();
  };

  return (
    <aside className="admin-sidebar">
      <div className="admin-sidebar-title">Admin Panel</div>
      <div className="admin-sidebar-divider"></div>
      <NavLink to="/admin/users" className="admin-sidebar-link">
        <span className="admin-sidebar-icon">
          {/* Users Icon */}
          <svg width="20" height="20" fill="white" viewBox="0 0 24 24">
            <path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5s-3 1.34-3 3 1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5C15 14.17 10.33 13 8 13zm8 0c-.29 0-.62.02-.97.05C17.16 14.1 19 15.03 19 16.5V19h5v-2.5c0-2.33-4.67-3.5-7-3.5z"/>
          </svg>
        </span>
        Users
      </NavLink>
      <NavLink to="/admin/fooditems" className="admin-sidebar-link">
        <span className="admin-sidebar-icon">
          {/* Food Items Icon */}
          <svg width="20" height="20" fill="white" viewBox="0 0 24 24">
            <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5S10.62 6.5 12 6.5s2.5 1.12 2.5 2.5S13.38 11.5 12 11.5z"/>
          </svg>
        </span>
        Food Items
      </NavLink>
      <div className="admin-sidebar-spacer"></div>
      <NavLink to="/admin/profile" className="admin-sidebar-link">
        <span className="admin-sidebar-icon">
          {/* Profile Icon */}
          <svg width="20" height="20" fill="white" viewBox="0 0 24 24">
            <circle cx="12" cy="8" r="4" />
            <path d="M12 14c-4.418 0-8 1.79-8 4v2h16v-2c0-2.21-3.582-4-8-4z"/>
          </svg>
        </span>
        Profile
      </NavLink>
      <button className="admin-sidebar-link admin-sidebar-logout" onClick={handleLogout} type="button">
        <span className="admin-sidebar-icon">
          {/* Logout Icon */}
          <svg width="22" height="22" fill="white" viewBox="0 0 24 24">
            <path d="M16 17v1a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h7a2 2 0 0 1 2 2v1" fill="none" stroke="white" strokeWidth="2"/>
            <polyline points="7 12 21 12" fill="none" stroke="white" strokeWidth="2"/>
            <polyline points="18 15 21 12 18 9" fill="none" stroke="white" strokeWidth="2"/>
          </svg>
        </span>
        Logout
      </button>
    </aside>
  );
}