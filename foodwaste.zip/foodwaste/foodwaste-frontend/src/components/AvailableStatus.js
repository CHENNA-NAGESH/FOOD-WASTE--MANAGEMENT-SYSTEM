import React, { useEffect, useState } from 'react';
import './AvailableStatus.css';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export default function AvailableStatus() {
  const [items, setItems] = useState([]);
  const user = JSON.parse(localStorage.getItem('user'));
  const navigate = useNavigate();

  useEffect(() => {
    axios.get('http://localhost:8080/api/food', {
      headers: {
        Authorization: `Bearer ${localStorage.getItem('token')}`
      }
    })
    .then(res => setItems(res.data))
    .catch(err => setItems([]));
  }, []);

  const isExpiringSoon = (expirationDate) => {
    const today = new Date();
    const exp = new Date(expirationDate);
    const diff = (exp - today) / (1000 * 60 * 60 * 24);
    return diff <= 3;
  };

  const handleRequestDonation = (item) => {
    navigate('/home/order-tracking', { state: { foodItem: item } });
  };

  // Only show items with status 'AVAILABLE'
  const availableItems = items.filter(item => item.status === 'AVAILABLE');

  return (
    <div className="available-bg">
      <div className="available-grid">
        {availableItems.map(item => (
          <div className="available-card" key={item.id}>
            <div className="available-header">
              <span className="available-title">{item.type?.toUpperCase() || 'FOOD'}</span>
              {isExpiringSoon(item.expirationDate) && (
                <span className="expires-soon">Expires Soon</span>
              )}
            </div>
            <div className="available-desc">{item.name}</div>
            <div className="available-info">
              <span>Quantity: {item.quantity}kg</span>
              <span>Expires: {item.expirationDate?.substring(0, 10)}</span>
            </div>
            <button
              className="available-btn"
              disabled={user && item.donor && user.id === item.donor.id}
              onClick={() => handleRequestDonation(item)}
            >
              Request Donation
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}