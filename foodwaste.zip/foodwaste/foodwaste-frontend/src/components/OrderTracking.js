import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { updateFoodItemStatus } from '../api';

export default function OrderTracking() {
  const location = useLocation();
  const navigate = useNavigate();
  const [foodItem, setFoodItem] = useState(location.state?.foodItem);

  if (!foodItem) {
    return <div>No food item selected.</div>;
  }

  const handleReceiveFood = async () => {
    try {
      await updateFoodItemStatus(foodItem.id, 'CLAIMED');
      setFoodItem({ ...foodItem, status: 'CLAIMED' });
      alert('Food item received and status updated!');
    } catch (err) {
      alert('Failed to update food item status.');
      console.error(err);
    }
  };

  return (
    <div style={{
      display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '80vh'
    }}>
      <div style={{
        background: '#f9f7fd',
        borderRadius: '16px',
        boxShadow: '0 4px 16px 0 rgba(60, 0, 90, 0.10)',
        padding: '2rem',
        minWidth: '350px',
        maxWidth: '500px',
        width: '100%',
        textAlign: 'left'
      }}>
        <h2>{foodItem.type?.toUpperCase() || 'FOOD'}</h2>
        <p><b>Name:</b> {foodItem.name}</p>
        <p><b>Quantity:</b> {foodItem.quantity}kg</p>
        <p><b>Expiration Date:</b> {foodItem.expirationDate?.substring(0, 10)}</p>
        <p><b>Status:</b> {foodItem.status}</p>
        <button
          style={{
            marginTop: '1.5rem',
            padding: '0.8rem 0',
            background: foodItem.status === 'CLAIMED' ? '#ccc' : '#7c3aed',
            color: '#fff',
            border: 'none',
            borderRadius: '8px',
            fontSize: '1.1rem',
            fontWeight: 'bold',
            cursor: foodItem.status === 'CLAIMED' ? 'not-allowed' : 'pointer',
            width: '100%'
          }}
          disabled={foodItem.status === 'CLAIMED'}
          onClick={handleReceiveFood}
        >
          {foodItem.status === 'CLAIMED' ? 'Already Received' : 'Receive Food'}
        </button>
      </div>
    </div>
  );
}