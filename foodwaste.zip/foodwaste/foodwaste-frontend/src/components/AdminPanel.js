import React from 'react';
import AdminSideBar from './AdminSideBar';
import { Outlet } from 'react-router-dom';

export default function AdminPanel() {
  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: '#f4f4f4' }}>
      <AdminSideBar />
      <main style={{ marginLeft: 220, padding: '2rem', width: '100%' }}>
        <Outlet />
      </main>
    </div>
  );
}