import React from 'react';
import { useNavigate } from 'react-router-dom';
import './HomeContent.css';

export default function HomeContent() {
  const navigate = useNavigate();

  return (
    <div className="homecontent-bg">
      <div className="homecontent-card">
        <h2>Welcome to Food Waste Management System</h2>
        <p>Choose an option to get started:</p>
        <div className="homecontent-btn-group">
          <button className="homecontent-btn" onClick={() => navigate('/home/donate')}>
            Donate
          </button>
          <button className="homecontent-btn" onClick={() => navigate('/home/available-status')}>
            Available Status
          </button>
        </div>
      </div>
    </div>
  );
}