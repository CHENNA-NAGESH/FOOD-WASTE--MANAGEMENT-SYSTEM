import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import './TopNavBar.css';

export default function TopNavBar() {
  const navigate = useNavigate();

  return (
    <nav className="top-navbar">
      <div className="top-navbar-left">
        <Link to="/home" className="nav-link">Home</Link>
        <Link to="/home/about" className="nav-link">About Us</Link>
        <Link to="/home/help" className="nav-link">Help</Link>
        <Link to="/home/contact" className="nav-link">Contact Us</Link>
      </div>
      <div className="top-navbar-right">
        <div
          className="profile-icon"
          onClick={() => navigate('/home/profile')}
          title="Profile"
        >
          <svg width="28" height="28" fill="white" viewBox="0 0 24 24">
            <circle cx="12" cy="8" r="4" />
            <path d="M12 14c-4.418 0-8 1.79-8 4v2h16v-2c0-2.21-3.582-4-8-4z"/>
          </svg>
        </div>
      </div>
    </nav>
  );
}