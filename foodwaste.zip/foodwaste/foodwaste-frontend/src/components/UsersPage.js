import React, { useEffect, useState } from 'react';
import axios from 'axios';
import tickIcon from '../assets/tick.png'; // Update path if needed
import './UsersPage.css';

export default function UsersPage() {
  const [users, setUsers] = useState([]);
  const [editUserId, setEditUserId] = useState(null);
  const [editForm, setEditForm] = useState({});

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = () => {
    axios.get('http://localhost:8080/api/admin/users', {
      headers: {
        Authorization: `Bearer ${localStorage.getItem('token')}`
      }
    })
    .then(res => setUsers(res.data))
    .catch(err => {
      setUsers([]);
      console.error('Error fetching users:', err);
    });
  };

  const handleEdit = (user) => {
    setEditUserId(user.id);
    setEditForm({
      name: user.name,
      email: user.email,
      role: user.role,
      location: user.location
    });
  };

  const handleEditChange = (e) => {
    setEditForm({ ...editForm, [e.target.name]: e.target.value });
  };

  const handleSave = (userId) => {
    axios.put(`http://localhost:8080/api/admin/users/${userId}`, editForm, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem('token')}`
      }
    })
    .then(() => {
      setEditUserId(null);
      fetchUsers();
    })
    .catch(err => {
      alert('Failed to update user');
      console.error(err);
    });
  };

  const handleDelete = (userId) => {
    if (window.confirm('Are you sure you want to delete this user?')) {
      axios.delete(`http://localhost:8080/api/admin/users/${userId}`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`
        }
      })
      .then(() => fetchUsers())
      .catch(err => {
        alert('Failed to delete user');
        console.error(err);
      });
    }
  };

  return (
    <div className="users-table-container">
      <table className="users-table">
        <thead>
          <tr>
            <th>NAME</th>
            <th>GMAIL</th>
            <th>ROLE</th>
            <th>LOCATION</th>
            <th style={{ textAlign: 'center' }}>ACCESS RIGHTS</th>
          </tr>
        </thead>
        <tbody>
          {users.map(user => (
            <tr key={user.id}>
              {editUserId === user.id ? (
                <>
                  <td>
                    <input
                      type="text"
                      name="name"
                      value={editForm.name}
                      onChange={handleEditChange}
                      className="edit-input"
                    />
                  </td>
                  <td>
                    <input
                      type="email"
                      name="email"
                      value={editForm.email}
                      onChange={handleEditChange}
                      className="edit-input"
                    />
                  </td>
                  <td>
                    <input
                      type="text"
                      name="role"
                      value={editForm.role}
                      onChange={handleEditChange}
                      className="edit-input"
                    />
                  </td>
                  <td>
                    <input
                      type="text"
                      name="location"
                      value={editForm.location}
                      onChange={handleEditChange}
                      className="edit-input"
                    />
                  </td>
                  <td>
                    <div className="access-rights-icons">
                      <img
                        src={tickIcon}
                        alt="Save"
                        className="icon-btn"
                        style={{ width: 24, height: 24 }}
                        title="Save"
                        onClick={() => handleSave(user.id)}
                      />
                    </div>
                  </td>
                </>
              ) : (
                <>
                  <td>
                    <div className="user-info">
                      <img
                        src={`https://ui-avatars.com/api/?name=${encodeURIComponent(user.name || user.email)}&background=7c3aed&color=fff&size=32`}
                        alt="avatar"
                        className="user-avatar"
                      />
                      <div>
                        <div className="user-name">{user.name}</div>
                        <div className="user-email">{user.email}</div>
                      </div>
                    </div>
                  </td>
                  <td>{user.email}</td>
                  <td>{user.role}</td>
                  <td>{user.location}</td>
                  <td>
                    <div className="access-rights-icons">
                      <span className="icon-btn" title="Edit" onClick={() => handleEdit(user)}>
                        {/* Grey Pencil Icon */}
                        <svg width="20" height="20" fill="#888" viewBox="0 0 24 24">
                          <path d="M3 17.25V21h3.75l11.06-11.06-3.75-3.75L3 17.25zM20.71 7.04a1.003 1.003 0 0 0 0-1.42l-2.34-2.34a1.003 1.003 0 0 0-1.42 0l-1.83 1.83 3.75 3.75 1.84-1.82z"/>
                        </svg>
                      </span>
                      <span className="icon-btn" title="Delete" onClick={() => handleDelete(user.id)}>
                        {/* Grey Cross Icon */}
                        <svg width="20" height="20" fill="#888" viewBox="0 0 24 24">
                          <path d="M18.3 5.71a1 1 0 0 0-1.41 0L12 10.59 7.11 5.7A1 1 0 0 0 5.7 7.11l4.89 4.89-4.89 4.89a1 1 0 1 0 1.41 1.41l4.89-4.89 4.89 4.89a1 1 0 0 0 1.41-1.41l-4.89-4.89 4.89-4.89a1 1 0 0 0 0-1.41z"/>
                        </svg>
                      </span>
                    </div>
                  </td>
                </>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}