import React from 'react';

export default function AdminProfilePage() {
  return <div>Admin - Profile Page</div>;
}