import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './UsersPage.css'; // Reuse the same table styles

export default function FoodItemsPage() {
  const [foodItems, setFoodItems] = useState([]);

  useEffect(() => {
    fetchFoodItems();
  }, []);

  const fetchFoodItems = () => {
    axios.get('http://localhost:8080/api/food', {
      headers: {
        Authorization: `Bearer ${localStorage.getItem('token')}`
      }
    })
    .then(res => setFoodItems(res.data))
    .catch(err => {
      setFoodItems([]);
      console.error('Error fetching food items:', err);
    });
  };

  const handleDelete = (foodId) => {
    if (window.confirm('Are you sure you want to delete this food item?')) {
      axios.delete(`http://localhost:8080/api/food/${foodId}`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`
        }
      })
      .then(() => fetchFoodItems())
      .catch(err => {
        alert('Failed to delete food item');
        console.error(err);
      });
    }
  };

  // Sort: available foods first, then claimed
  const sortedItems = [
    ...foodItems.filter(item => item.status === 'AVAILABLE'),
    ...foodItems.filter(item => item.status === 'CLAIMED')
  ];

  return (
    <div className="users-table-container">
      <table className="users-table">
        <thead>
          <tr>
            <th>DONOR NAME</th>
            <th>FOOD NAME</th>
            <th>QUANTITY</th>
            <th>TYPE</th>
            <th>EXPIRATION DATE</th>
            <th>STATUS</th>
            <th style={{ textAlign: 'center' }}></th>
          </tr>
        </thead>
        <tbody>
          {sortedItems.map(item => (
            <tr key={item.id}>
              <td>{item.donor?.name || 'Unknown'}</td>
              <td>{item.name}</td>
              <td>{item.quantity}</td>
              <td>{item.type}</td>
              <td>{item.expirationDate?.substring(0, 10)}</td>
              <td>
                <span
                  style={{
                    color: item.status === 'AVAILABLE' ? '#059669' : '#e11d48',
                    fontWeight: 600
                  }}
                >
                  {item.status}
                </span>
              </td>
              <td>
                <div className="access-rights-icons">
                  <span className="icon-btn" title="Delete" onClick={() => handleDelete(item.id)}>
                    {/* Grey Cross Icon */}
                    <svg width="20" height="20" fill="#888" viewBox="0 0 24 24">
                      <path d="M18.3 5.71a1 1 0 0 0-1.41 0L12 10.59 7.11 5.7A1 1 0 0 0 5.7 7.11l4.89 4.89-4.89 4.89a1 1 0 1 0 1.41 1.41l4.89-4.89 4.89 4.89a1 1 0 0 0 1.41-1.41l-4.89-4.89 4.89-4.89a1 1 0 0 0 0-1.41z"/>
                    </svg>
                  </span>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}