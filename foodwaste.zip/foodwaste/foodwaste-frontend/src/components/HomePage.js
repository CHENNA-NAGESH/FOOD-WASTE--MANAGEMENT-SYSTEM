import TopNavBar from './TopNavBar';
import SideBar from './SideBar';
import './HomePage.css';
import { Outlet } from 'react-router-dom';

export default function HomePage() {
  return (
    <div className="home-root">
      <TopNavBar />
      <div className="home-content">
        <SideBar />
        <main className="main-content">
          <Outlet />
        </main>
      </div>
    </div>
  );
}