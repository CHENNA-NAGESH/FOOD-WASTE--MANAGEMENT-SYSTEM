import React, { useState } from 'react';
import './Donate.css';
import { addFoodItem } from '../api';
import { useNavigate } from 'react-router-dom';

export default function Donate() {
  const user = JSON.parse(localStorage.getItem('user'));
  const navigate = useNavigate();

  const [form, setForm] = useState({
    name: '',
    quantity: '',
    type: '',
    expirationDate: '',
    status: 'AVAILABLE'
  });
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  const handleChange = e => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async e => {
    e.preventDefault();
    setError('');
    setSuccess('');
    if (!user || !user.id) {
      setError('User not logged in.');
      return;
    }
    try {
      await addFoodItem({
        ...form,
        donor: { id: user.id }
      });
      setSuccess('Food item donated successfully!');
      setForm({
        name: '',
        quantity: '',
        type: '',
        expirationDate: '',
        status: 'AVAILABLE'
      });
      setTimeout(() => {
        navigate('/home/available-status');
      }, 1000);
    } catch (err) {
      setError('Failed to donate food item.');
      if (err.response) {
        console.error('Backend error:', err.response.data);
      } else {
        console.error('Network or other error:', err);
      }
    }
  };

  return (
    <div className="donate-bg">
      <form className="donate-form" onSubmit={handleSubmit}>
        <h2>Donate Food Item</h2>
        <p className="donate-subtitle">Please fill in the details below</p>
        <label>Name of Food Item</label>
        <input
          type="text"
          name="name"
          placeholder="Food name"
          value={form.name}
          onChange={handleChange}
          required
        />
        <label>Quantity</label>
        <input
          type="number"
          name="quantity"
          placeholder="Quantity"
          value={form.quantity}
          onChange={handleChange}
          required
        />
        <label>Type</label>
        <input
          type="text"
          name="type"
          placeholder="Type (e.g. Veg, Non-Veg, Fruit)"
          value={form.type}
          onChange={handleChange}
          required
        />
        <label>Expiration Date</label>
        <input
          type="date"
          name="expirationDate"
          value={form.expirationDate}
          onChange={handleChange}
          required
        />
        <label>Status</label>
        <select name="status" value={form.status} onChange={handleChange} required>
          <option value="AVAILABLE">Available</option>
          <option value="CLAIMED">Claimed</option>
        </select>
        <button className="donate-btn" type="submit">Donate</button>
        {success && <div className="donate-success">{success}</div>}
        {error && <div className="donate-error">{error}</div>}
      </form>
    </div>
  );
}