import axios from 'axios';

const API_URL = 'http://localhost:8080/api';

export const login = (email, password) =>
  axios.post(`${API_URL}/auth/login`, { email, password });

export const signup = (user) =>
  axios.post(`${API_URL}/auth/signup`, user);

export const addFoodItem = (foodItem) =>
  axios.post(`${API_URL}/food`, foodItem, {
    headers: {
      Authorization: `Bearer ${localStorage.getItem('token')}`
    }
  });

export const getCurrentUser = () =>
  axios.get(`${API_URL}/auth/me`, {
    headers: {
      Authorization: `Bearer ${localStorage.getItem('token')}`
    }
  });

export const getAllUsers = () =>
  axios.get(`${API_URL}/admin/users`, {
    headers: {
      Authorization: `Bearer ${localStorage.getItem('token')}`
    }
  });

// Update food item status
export const updateFoodItemStatus = (id, status) =>
  axios.put(`${API_URL}/food/${id}/status`, { status }, {
    headers: {
      Authorization: `Bearer ${localStorage.getItem('token')}`
    }
  });