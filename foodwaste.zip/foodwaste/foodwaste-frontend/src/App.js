import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import LoginPage from './components/LoginPage';
import HomePage from './components/HomePage';
import HomeContent from './components/HomeContent';
import About from './components/About';
import Help from './components/Help';
import Donate from './components/Donate';
import OrderTracking from './components/OrderTracking';
import AvailableStatus from './components/AvailableStatus';
import Profile from './components/Profile';

// Admin imports
import AdminPanel from './components/AdminPanel';
import UsersPage from './components/UsersPage';
import FoodItemsPage from './components/FoodItemsPage';
import AdminProfilePage from './components/AdminProfilePage';

function App() {
  return (
    <Router>
      <Routes>
        {/* Login */}
        <Route path="/" element={<LoginPage />} />

        {/* User Home */}
        <Route path="/home" element={<HomePage />}>
          <Route index element={<HomeContent />} />
          <Route path="about" element={<About />} />
          <Route path="help" element={<Help />} />
          <Route path="contact" element={<About />} />
          <Route path="donate" element={<Donate />} />
          <Route path="order-tracking" element={<OrderTracking />} />
          <Route path="available-status" element={<AvailableStatus />} />
          <Route path="profile" element={<Profile />} />
        </Route>

        {/* Admin Panel */}
        <Route path="/admin" element={<AdminPanel />}>
          <Route path="users" element={<UsersPage />} />
          <Route path="fooditems" element={<FoodItemsPage />} />
          <Route path="profile" element={<AdminProfilePage />} />
        </Route>
      </Routes>
    </Router>
  );
}

export default App;