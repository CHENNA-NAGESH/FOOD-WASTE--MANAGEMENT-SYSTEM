package com.example.foodwaste;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodWasteBackend3Application {
    public static void main(String[] args) {
        SpringApplication.run(FoodWasteBackend3Application.class, args);
    }
}