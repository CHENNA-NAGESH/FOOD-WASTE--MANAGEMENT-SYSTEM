package com.example.foodwaste.controller;

import com.example.foodwaste.model.Donation;
import com.example.foodwaste.service.DonationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/donation")
@CrossOrigin(origins = "*")
public class DonationController {

    @Autowired
    private DonationService donationService;

    @GetMapping
    public List<Donation> getAllDonations() {
        return donationService.getAll();
    }

    @PostMapping
    public Donation createDonation(@RequestBody Donation donation) {
        return donationService.save(donation);
    }
}