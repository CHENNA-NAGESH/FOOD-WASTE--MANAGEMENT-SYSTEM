package com.example.foodwaste.service;

import com.example.foodwaste.model.User;
import com.example.foodwaste.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    public User authenticate(String email, String password) {
        return userRepository.findByEmailAndPassword(email, password).orElse(null);
    }

    public void save(User user) {
        userRepository.save(user);
    }

    public Optional<User> findByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    // Method to get all users
    public List<User> getAll() {
        return userRepository.findAll();
    }
    public Optional<User> findById(Integer id) {
        return userRepository.findById(id);
    }

    public boolean existsById(Integer id) {
        return userRepository.existsById(id);
    }

    public void deleteById(Integer id) {
        userRepository.deleteById(id);
    }
}