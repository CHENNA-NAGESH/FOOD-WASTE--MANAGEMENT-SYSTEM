
package com.example.foodwaste.service;

import com.example.foodwaste.model.Donation;
import com.example.foodwaste.repository.DonationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class DonationService {
    @Autowired
    private DonationRepository donationRepository;

    public List<Donation> getAll() { return donationRepository.findAll(); }
    public Donation save(Donation donation) { return donationRepository.save(donation); }
}