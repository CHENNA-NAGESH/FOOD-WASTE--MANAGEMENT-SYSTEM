package com.example.foodwaste.service;

import com.example.foodwaste.model.FoodItem;
import com.example.foodwaste.repository.FoodItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class FoodItemService {
    @Autowired
    private FoodItemRepository foodItemRepository;

    public List<FoodItem> getAll() { return foodItemRepository.findAll(); }
    public FoodItem save(FoodItem item) { return foodItemRepository.save(item); }
    public boolean existsById(Integer id) {
        return foodItemRepository.existsById(id);
    }

    public void deleteById(Integer id) {
        foodItemRepository.deleteById(id);
    }
    public Optional<FoodItem> getById(Integer id) {
        return foodItemRepository.findById(id);
    }
}
