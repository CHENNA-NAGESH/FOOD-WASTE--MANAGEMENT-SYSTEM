package com.example.foodwaste.controller;

import com.example.foodwaste.model.FoodItem;
import com.example.foodwaste.service.FoodItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/food")
@CrossOrigin(origins = "*")
public class FoodItemController {

    @Autowired
    private FoodItemService foodItemService;

    @GetMapping
    public List<FoodItem> getAll() {
        return foodItemService.getAll();
    }

    @PostMapping
    public ResponseEntity<?> addFoodItem(@RequestBody FoodItem foodItem) {
        if (foodItem.getStatus() == null) {
            foodItem.setStatus(FoodItem.Status.AVAILABLE);
        }
        foodItemService.save(foodItem);
        return ResponseEntity.ok("Food item added successfully");
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<?> updateFoodItemStatus(@PathVariable Integer id, @RequestBody FoodItem updatedItem) {
        Optional<FoodItem> foodItemOpt = foodItemService.getById(id);
        if (foodItemOpt.isPresent()) {
            FoodItem foodItem = foodItemOpt.get();
            foodItem.setStatus(updatedItem.getStatus());
            foodItemService.save(foodItem);
            return ResponseEntity.ok("Food item status updated successfully");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Food item not found");
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteFoodItem(@PathVariable Integer id) {
        if (foodItemService.existsById(id)) {
            foodItemService.deleteById(id);
            return ResponseEntity.ok("Food item deleted successfully");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Food item not found");
        }
    }
}