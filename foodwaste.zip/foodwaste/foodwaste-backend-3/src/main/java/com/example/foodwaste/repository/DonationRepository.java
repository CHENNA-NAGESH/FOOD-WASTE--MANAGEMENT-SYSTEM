package com.example.foodwaste.repository;

import com.example.foodwaste.model.Donation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DonationRepository extends JpaRepository<Donation, Integer> {}	